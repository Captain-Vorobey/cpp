#ifndef PREDICATES_H_INCLUDED
#define PREDICATES_H_INCLUDED
#include <cmath>

bool min_(int value1, int value2)
{
    return value1 < value2;
}

bool max_(int value1, int value2)
{
    return value1 > value2;
}



#endif // PREDICATES_H_INCLUDED
